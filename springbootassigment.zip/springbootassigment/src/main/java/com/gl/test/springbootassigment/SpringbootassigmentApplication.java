package com.gl.test.springbootassigment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootassigmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootassigmentApplication.class, args);
	}

}
