package com.gl.test.springbootassigment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootassigmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
